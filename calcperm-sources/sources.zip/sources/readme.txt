You have downloaded these sources from
  http://programming.sirrida.de
For more information consult this web site.

(c) 2011..2017 Jasper L. Neumann

I have granted the sources to the public domain.
That means that any discoveries and/or inventions made by me
shall not be patented but shall be treated as prior art.
However please do not adorn yourself with borrowed plumes,
i.e. do not pretend that you have invented it yourself.

You are hereby granted the right use, copy, and distribute
any of this code, whether modified by you or not.
You need not give attribution.

The author has taken care in the preparation of this material,
but makes no expressed or implied warranty of any kind and assumes
no responsibility for errors or omissions.
No liability is assumed for incidental or consequential damages
in connection with or arising out of the use of the information or
programs contained herein.

If you have comments or questions or find any bugs,
please don't hesitate to send an e-mail to
  info@sirrida.de

Have fun
Jasper Neumann
