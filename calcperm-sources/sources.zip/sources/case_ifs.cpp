//////
// Intro

// Switch on string

// (c) 2011..2017 by Jasper L. Neumann
// www.sirrida.de / programming.sirrida.de
// E-Mail: info@sirrida.de

// Granted to the public domain
// First version: 2013-02-20
// Last change: 2013-03-04

// Stupid prototype with else-if chain (STL strings).
// You need a C++ compiler because of string.
// g++
// Not checked for dupes.

#include "case_ifs.hpp"

// eof.
